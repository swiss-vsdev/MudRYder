package ch.hevs.gdx2d.desktop;

import com.badlogic.gdx.Files;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.badlogic.gdx.utils.SharedLibraryLoader;
import java.awt.GraphicsEnvironment;

/**
 * Default configuration for {@code gdx2d} applications running on desktop.
 *
 * @author Pierre-André Mudry (mui)
 */
public class GdxConfig {

    static public Lwjgl3ApplicationConfiguration getLwjgl3Config(int width, int height, boolean fullScreen) {
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setResizable(false);
        config.useVsync(true);
        config.setForegroundFPS(60);
        config.setIdleFPS(60);
        config.setBackBufferConfig(8, 8, 8, 8, 16, 0, 3);
        config.setTitle("Gdx2d desktop application");
        config.setHdpiMode(Lwjgl3ApplicationConfiguration.HdpiMode.Logical);

        if (fullScreen) {
            config.setFullscreenMode(Lwjgl3ApplicationConfiguration.getDisplayMode());
        } else {
            double scale = GraphicsEnvironment
                .getLocalGraphicsEnvironment()
                .getDefaultScreenDevice()
                .getDefaultConfiguration()
                .getDefaultTransform()
                .getScaleX();
            System.out.println("Detected scale: " + scale); // ← AJOUTER
            config.setWindowedMode((int)(width / scale), (int)(height / scale));
        }

        if (SharedLibraryLoader.isWindows) {
            config.setWindowIcon(Files.FileType.Internal,
                "res/lib/icon16.png", "res/lib/icon32.png", "res/lib/icon64.png");
        } else {
            config.setWindowIcon(Files.FileType.Internal,
                "res/lib/icon32.png", "res/lib/icon64.png");
        }

        return config;
    }
}